// ControlButtons.jsx
import React from 'react';

const ControlButtons = ({ capturing, handleStartCaptureClick, handleStopCaptureClick }) => (
  <div className="control-buttons">
    {capturing ? (
      <button className="control-button" onClick={handleStopCaptureClick}>Stop Capture</button>
    ) : (
      <button className="control-button" onClick={handleStartCaptureClick}>Start Capture</button>
    )}
  </div>
);

export default ControlButtons;
