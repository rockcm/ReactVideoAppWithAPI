import React, { useEffect, useState } from 'react';
import axios from 'axios';
import './VideoList.css'; 

const VideoList = () => {
  const [videos, setVideos] = useState([]);

  useEffect(() => {
    fetchVideos();
  }, []);

  const fetchVideos = () => {
    axios.get('http://localhost:8000/videos')
      .then((response) => {
        setVideos(response.data.videos);
        console.log('Fetched videos:', response.data.videos); // Log fetched videos
      })
      .catch((error) => {
        console.error('Error fetching videos:', error);
      });
  };

  const handleDelete = (videoId) => {
    console.log(`Attempting to delete video with id: ${videoId}`); // Log delete attempt
    axios.delete(`http://localhost:8000/videos/${videoId}`)
      .then((response) => {
        console.log('Video deleted successfully:', response.data);
        fetchVideos(); // Re-fetch the list of videos
      })
      .catch((error) => {
        console.error('Error deleting video:', error);
      });
  };

  return (
    <div className="video-list">
      <h2>Uploaded Videos</h2>
      {videos.map((video) => (
        <div key={video.id} className="video-item">
          <video controls>
            <source src={`http://localhost:8000/videos/${video.id}`} type="video/webm" />
            Your browser does not support the video tag.
          </video>
          <p>{video.filename}</p>
          <button onClick={() => handleDelete(video.id)}>Delete</button>
        </div>
      ))}
    </div>
  );
};

export default VideoList;
