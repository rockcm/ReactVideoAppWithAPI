// Cam.jsx
import React, { useState, useRef } from 'react';
import axios from 'axios';
import WebcamStream from './WebcamStream';
import ControlButtons from './ControlButtons';
import VideoNameInput from './VideoNameInput';
import './Cam.css';

const Cam = () => {
  const mediaRecorderRef = useRef(null);
  const [capturing, setCapturing] = useState(false);
  const [recordedChunks, setRecordedChunks] = useState([]);
  const [mediaStream, setMediaStream] = useState(null);
  const [videoUrl, setVideoUrl] = useState(null);
  const [videoName, setVideoName] = useState("");
  const [isRecordingStopped, setIsRecordingStopped] = useState(false);

  const handleStartCaptureClick = () => {
    if (!mediaStream) {
      console.error("Media stream not available.");
      return;
    }

    setCapturing(true);
    setIsRecordingStopped(false);

    mediaRecorderRef.current = new MediaRecorder(mediaStream, {
      mimeType: "video/webm"
    });

    mediaRecorderRef.current.addEventListener(
      "dataavailable",
      ({ data }) => {
        if (data.size > 0) {
          setRecordedChunks(prev => [...prev, data]);
        }
      }
    );

    mediaRecorderRef.current.start();
  };

  const handleStopCaptureClick = () => {
    if (mediaRecorderRef.current && mediaRecorderRef.current.state === 'recording') {
      mediaRecorderRef.current.stop();
      setCapturing(false);
      setIsRecordingStopped(true);
    }
  };

  const handleUpload = async () => {
    if (recordedChunks.length && videoName) {
      const blob = new Blob(recordedChunks, {
        type: "video/webm"
      });

      const formData = new FormData();
      formData.append("video", blob, "recorded-video.webm");
      formData.append("name", videoName);

      try {
        const response = await axios.post("http://localhost:8000/upload", formData, {
          headers: {
            "Content-Type": "multipart/form-data"
          }
        });

        console.log("Video uploaded successfully:", response.data);

        setVideoUrl(response.data.path);
        alert("Video uploaded successfully!");
        window.location.reload();
      } catch (error) {
        console.error("Error uploading video:", error);
      }

      setRecordedChunks([]);
      setVideoName("");
      setIsRecordingStopped(false);
    }
  };

  return (
    <div className="cam-container">
      <WebcamStream setMediaStream={setMediaStream} />
      <ControlButtons
        capturing={capturing}
        handleStartCaptureClick={handleStartCaptureClick}
        handleStopCaptureClick={handleStopCaptureClick}
      />
      {!capturing && isRecordingStopped && (
        <VideoNameInput
          videoName={videoName}
          setVideoName={setVideoName}
          handleUpload={handleUpload}
        />
      )}
    </div>
  );
};

export default Cam;
