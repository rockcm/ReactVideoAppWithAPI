// WebcamStream.jsx
import React, { useRef, useEffect } from 'react';
import Webcam from 'react-webcam';

const WebcamStream = ({ setMediaStream }) => {
  const webcamRef = useRef(null);

  useEffect(() => {
    const getMediaStream = async () => {
      try {
        const stream = await navigator.mediaDevices.getUserMedia({
          video: true,
          audio: true,
        });

        setMediaStream(stream);

        if (webcamRef.current) {
          webcamRef.current.video.srcObject = stream;
          webcamRef.current.video.muted = true; // Mute the video to prevent feedback
        }
      } catch (error) {
        console.error("Error accessing media devices:", error);
      }
    };

    getMediaStream();
  }, [setMediaStream]);

  return <Webcam audio={true} ref={webcamRef} className="webcam-video" />;
};

export default WebcamStream;
