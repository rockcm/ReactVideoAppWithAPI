// main.jsx
import React from 'react';
import ReactDOM from 'react-dom';
import Cam from './Cam';
import VideoList from './VideoList';
import './index.css'; // Import the global CSS file

const App = () => {
  return (
    <div className="container">
      <h1>Social Media Video App</h1>
      <Cam />
      <VideoList />
    </div>
  );
};

ReactDOM.render(<App />, document.getElementById('root'));
