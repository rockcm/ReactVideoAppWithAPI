// VideoNameInput.jsx
import React from 'react';

const VideoNameInput = ({ videoName, setVideoName, handleUpload }) => (
  <div className="video-name-input-container">
    <input
      type="text"
      placeholder="Enter video name"
      value={videoName}
      onChange={(e) => setVideoName(e.target.value)}
      className="video-name-input"
    />
    <button className="control-button" onClick={handleUpload}>Upload</button>
  </div>
);

export default VideoNameInput;
