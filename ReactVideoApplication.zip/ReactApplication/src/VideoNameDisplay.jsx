import React from 'react';

const VideoNameDisplay = ({ name }) => {
  return (
    <div>
      <h2>Video Name: {name}</h2>
    </div>
  );
};

export default VideoNameDisplay;
