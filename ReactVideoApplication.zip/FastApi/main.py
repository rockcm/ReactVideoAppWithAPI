from fastapi import FastAPI, File, UploadFile, Form, HTTPException
from fastapi.responses import StreamingResponse
from pydantic import BaseModel
from typing import List
from pathlib import Path
from fastapi.middleware.cors import CORSMiddleware
import shutil
import os

# Create a FastAPI instance
app = FastAPI()

# Add CORS middleware to allow cross-origin requests
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # Allows all origins
    allow_credentials=True,
    allow_methods=["GET", "POST", "PUT", "DELETE"],
    allow_headers=["*"],
)

# Define the data models using Pydantic
class Video(BaseModel):
    id: int
    filename: str
    path: str

class VideoUpload(BaseModel):
    filename: str
    path: str

class VideoResponse(BaseModel):
    videos: List[Video]

# Endpoint to upload a video
@app.post('/upload', response_model=VideoUpload)
async def upload_video(video: UploadFile = File(...), name: str = Form(...)):
    try:
        # Save the video file to the uploads directory with the provided name
        upload_folder = Path("uploads")
        if not upload_folder.exists():
            upload_folder.mkdir()

        # Use the provided name as the filename
        video_path = upload_folder / f"{name}.webm"

        # Save the uploaded file to disk
        with open(video_path, 'wb') as f:
            shutil.copyfileobj(video.file, f)

        print(f"Video saved at {video_path}")  # Debug statement

        # Return metadata of the uploaded video
        return VideoUpload(filename=name, path=str(video_path))
    except Exception as e:
        print(f"Error saving video: {e}")  # Debug statement
        raise HTTPException(status_code=500, detail=str(e))

# Endpoint to list all uploaded videos
@app.get('/videos', response_model=VideoResponse)
async def list_videos():
    try:
        upload_folder = Path("uploads")
        videos = []
        
        # Iterate over each file in the uploads directory
        for video_path in upload_folder.iterdir():
            # Append video metadata to the videos list
            videos.append(Video(id=len(videos)+1, filename=video_path.stem, path=str(video_path)))
        
        print(f"Videos listed: {videos}")  # Debug statement

        # Return list of all uploaded videos
        return VideoResponse(videos=videos)
    except Exception as e:
        print(f"Error listing videos: {e}")  # Debug statement
        raise HTTPException(status_code=500, detail=str(e))

# Endpoint to stream a video
@app.get('/videos/{video_id}')
async def get_video(video_id: int):
    try:
        upload_folder = Path("uploads")
        videos = sorted([video for video in upload_folder.iterdir()])
        
        # Validate the requested video_id
        if video_id < 1 or video_id > len(videos):
            raise HTTPException(status_code=404, detail="Video not found")
        
        # Get the path of the requested video
        video_path = videos[video_id - 1]
        video_size = video_path.stat().st_size

        # Function to generate video stream
        def generate():
            with open(video_path, 'rb') as f:
                while True:
                    chunk = f.read(1024 * 1024)  # 1 MB chunks
                    if not chunk:
                        break
                    yield chunk

        # Return the video as a streaming response
        return StreamingResponse(
            generate(),
            media_type='video/webm',
            headers={
                "Content-Disposition": f"inline; filename={video_path.name}",
                "Content-Length": str(video_size),
            }
        )
    except Exception as e:
        print(f"Error streaming video: {e}")  # Debug statement
        raise HTTPException(status_code=500, detail=str(e))

# Endpoint to delete a video
@app.delete('/videos/{video_id}', response_model=Video)
async def delete_video(video_id: int):
    try:
        upload_folder = Path("uploads")
        videos = list(sorted(upload_folder.iterdir()))
        
        # Validate the requested video_id
        if video_id < 1 or video_id > len(videos):
            raise HTTPException(status_code=404, detail="Video not found")
        
        # Get the path of the requested video
        video_path = videos[video_id - 1]
        
        # Check if the video file exists
        if not video_path.exists():
            raise HTTPException(status_code=404, detail="Video file not found")

        # Close the file stream before deleting
        with open(video_path, 'rb') as f:
            f.close()

        # Delete the video file
        os.remove(video_path)
        print(f"Video deleted: {video_path}")  # Debug statement

        # Return metadata of the deleted video
        return Video(id=video_id, filename=video_path.stem, path=str(video_path))
    except HTTPException as http_err:
        print(f"HTTP error deleting video: {http_err}")  # Debug statement
        raise http_err
    except Exception as e:
        print(f"Error deleting video: {e}")  # Debug statement
        raise HTTPException(status_code=500, detail=str(e))


# Run the FastAPI application with uvicorn server
if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="127.0.0.1", port=8000)
